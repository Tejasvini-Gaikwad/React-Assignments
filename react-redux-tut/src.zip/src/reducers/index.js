import { combineReducers } from "redux";
import { userData } from "./reducer";

export const rootReducers = combineReducers({
    userData
})