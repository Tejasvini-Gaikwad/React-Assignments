export const ACTION_REDUCER = {
    'SET_SORT' : 'SET_SORT'
} 