import React from "react";

const ToDoContext = React.createContext();

export default ToDoContext;
